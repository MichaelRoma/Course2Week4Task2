//
//  ViewController.swift
//  Course2Week4Task2
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class CABasicAnimationController: UIViewController {
    
    @IBOutlet weak var orangeView: UIView!
    @IBOutlet weak var cyanView: UIView!
    @IBOutlet weak var blueView: UIView!
    @IBOutlet weak var greenView: UIView!
    
    @IBOutlet weak var orangeButton: UIButton!
    @IBOutlet weak var greenButton: UIButton!
    @IBOutlet weak var cyanButton: UIButton!
    @IBOutlet weak var blueButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        orangeButton.setTitle("Click Me", for: .normal)
        orangeButton.tintColor = .black
        blueButton.setTitle("Click Me", for: .normal)
        blueButton.tintColor = .black
        cyanButton.setTitle("Click Me", for: .normal)
        cyanButton.tintColor = .black
        greenButton.setTitle("Click Me", for: .normal)
        greenButton.tintColor = .black
        
    }
    @IBAction func orangePress(_ sender: Any) {
        setUpOrangeViewAnimation()
        orangeButton.setTitle("Pressed", for: .normal)
    }
    
    @IBAction func bluePress(_ sender: Any) {
        setUpBlueViewAnimation()
        blueButton.setTitle("Pressed", for: .normal)
    }
    
    @IBAction func cyanPrees(_ sender: Any) {
        setUpCaynViewAnimation()
        cyanButton.setTitle("Pressed", for: .normal)
    }
    
    @IBAction func greenPress(_ sender: Any) {
        setUpGreenViewAnimation()
        greenButton.setTitle("Pressed", for: .normal)
    }
    
    private func setUpOrangeViewAnimation() {
        
        orangeView.frame = CGRect(x: 20, y: 40, width: 100, height: 100)
        view.addSubview(orangeView)
        let roundAnimation = createAnObject(
                 keyPath: "cornerRadius",
                 fromValue: 0,
                 toValue: 50,
                 repeatCount: 1,
                 duration: 1)
        orangeView.layer.add(roundAnimation, forKey: nil)
    }
    
    private func setUpCaynViewAnimation() {
        cyanView.frame = CGRect(x: 294, y: 40, width: 100, height: 100)
        view.addSubview(cyanView)
        let fadeAnimation = createAnObject(
                keyPath: "opacity",
                fromValue: 1,
                toValue: 0,
                repeatCount: 1,
                duration: 1,
                nameForTimingFunction: .easeIn)
        cyanView.layer.add(fadeAnimation, forKey: nil)
        
    }
    
    private func setUpBlueViewAnimation() {
        blueView.frame = CGRect(x: 20, y: 200, width: 100, height: 100)
        view.addSubview(blueView)
        let rotateAnimation = createAnObject(
                keyPath: "transform.rotation",
                fromValue: 0.0,
                toValue: 5.498,
                repeatCount: 1,
                duration: 2)
        let moveAnimation = createAnObject(
                keyPath: #keyPath(CALayer.position),
                fromValue: blueView.center,
                toValue: CGPoint(x: cyanView.center.x, y: blueView.center.y),
                repeatCount: 1,
                duration: 2)
        
       let groupAnimation = CAAnimationGroup()
        groupAnimation.animations = [rotateAnimation, moveAnimation]
        groupAnimation.duration = 2
        groupAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        groupAnimation.fillMode = .forwards
        groupAnimation.isRemovedOnCompletion = false
        blueView.layer.add(groupAnimation, forKey: "groupBlue")
       
    }
    
    private func setUpGreenViewAnimation() {
        greenView.frame = CGRect(x: 20, y: 616, width: 100, height: 100)
        view.addSubview(blueView)
        
        let moveAnimation = createAnObject(
                keyPath: #keyPath(CALayer.position),
                fromValue: greenView.center,
                toValue: view.center,
                repeatCount: 2,
                duration: 1)
        moveAnimation.autoreverses = true
        moveAnimation.fillMode = .removed
        moveAnimation.isRemovedOnCompletion = true
        
        let collorChange = createAnObject(
                keyPath: "backgroundColor",
                fromValue: UIColor.green.cgColor,
                toValue: UIColor.magenta.cgColor,
                repeatCount: 2,
                duration: 1)
        collorChange.autoreverses = true
        collorChange.fillMode = .removed
        collorChange.isRemovedOnCompletion = true
        
        let scaleAnimation = createAnObject(
                keyPath: "transform.scale",
                fromValue: CGPoint(x: 1, y: 1),
                toValue: CGPoint(x: 1.5, y: 1.5),
                repeatCount: 2,
                duration: 1)
        scaleAnimation.autoreverses = true
        scaleAnimation.fillMode = .removed
        scaleAnimation.isRemovedOnCompletion = true
        
        let groupAnimation = CAAnimationGroup()
               groupAnimation.animations = [moveAnimation, collorChange,scaleAnimation]
               groupAnimation.duration = 2
               groupAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
               groupAnimation.autoreverses = true
               greenView.layer.add(groupAnimation, forKey: "groupGreen")
        
    }
}

extension CABasicAnimationController {
    
    func createAnObject(keyPath: String, fromValue: Any, toValue: Any, repeatCount: Float, duration: CFTimeInterval, nameForTimingFunction: CAMediaTimingFunctionName = .easeInEaseOut ) -> CABasicAnimation {
        
        let animationView = CABasicAnimation(keyPath: keyPath)
        animationView.fromValue = fromValue
        animationView.toValue = toValue
        animationView.repeatCount = repeatCount
        animationView.duration = duration
        animationView.timingFunction = CAMediaTimingFunction(name:  nameForTimingFunction)
        animationView.fillMode = .forwards
        animationView.isRemovedOnCompletion = false
        return animationView
    }
    
}
